document.getElementById('downloadBtn').addEventListener('click', function(event) {
    if (!confirm('לשמור כקובץ?')) {
     event.preventDefault();
  }
});